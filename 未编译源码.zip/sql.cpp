#include "sql.h"
#include"login.h"
sql::sql()
{
   // this->db=  QSqlDatabase::addDatabase("QSQLITE","qt_sql_default_connection");
    QSqlDatabase qdb;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
        qdb = QSqlDatabase::database("qt_sql_default_connection");
    else
        qdb = QSqlDatabase::addDatabase("QSQLITE");
    this->db=qdb;
    this->db.setHostName("127.0.0.1"); // 数据库服务器IP，我用的是本地电脑
    this-> db.setDatabaseName("mysql.db");// 数据库名
    this->db.setUserName("root");// 用户名
    this->db.setPassword("123456");// 密码
    this-> db.setPort(3306);// 端口号
    bool ok =this->db.open();

    if (ok)
    {
        qDebug() << "database connect is ok";
    }
    else
    {
        qDebug() << "database connect is fail";
    }

}
//遍历全部数据库
void sql::sql_find(QSqlDatabase db)
{
    QString sql_s = "SELECT username, userpassword FROM user_information" ; // 组装sql语句
    QSqlQuery query(db);                               // [1] 传入数据库连接
    query.exec(sql_s);                                   // [2] 执行sql语句
    while (query.next()) {                             // [3] 遍历查询结果
        qDebug() << QString("%1, %2")
                        .arg(query.value("username").toString())
                        .arg(query.value("userpassword").toString());
    }
}
//用户信息查询函数
int sql::sql_find_certified(QSqlDatabase db,const QString &name,const QString &password)
{
    //int i=0;
    QSqlQuery query(db);    // [1] 传入数据库连接
    QString sql;
    sql = "SELECT * FROM user_information WHERE username='" + name + "'";
        //多条遍历用循环
        //单条直接query.next();
    query.exec(sql);
    //查看搜索结果
    query.next();
    if(name ==query.value("username").toString()&&name.size()!=0 &&password==query.value("userpassword").toString()&&password.size()!=0){
        return 1;

    }
    //密码相等 账户相等
    //账户相等 密码不相等
    if(name ==query.value("username").toString()&&name.size()!=0 &&password!=query.value("userpassword").toString()&&password.size()!=0){
        return 2;
    }
    //账户不相等 密码不相等
    if(name !=query.value("username").toString()&&name.size()!=0) {
        return 3;
    }
}
//判断登录程序
int sql::sql_find_login(QSqlDatabase db, const QString &name,const QString &password)
{
    //int i=0;
    QSqlQuery query(db);    // [1] 传入数据库连接
    QString sql ;
    sql = "SELECT * FROM user_information WHERE username='" + name + "'";
        //多条遍历用循环
        //单挑直接query.next();
    qDebug()<<"判断";
    query.exec(sql);
    //查看搜索结果
    query.next();
    if(name ==query.value("username").toString()&&name.size()!=0 ){
        if(password ==query.value("userpassword").toString() &&password.size()!=0){
            return 3;
        }
        else{
            return 2;
        }
    }
    else{
        return 1;
    }
}
//数据库添加用户数据
void sql::sql_add(QSqlDatabase db,  const QString &name, const QString &password)
{
    qDebug()<<"添加数据"<<'\n';
    QSqlQuery query(db);
    // 获取数据库
    qDebug()<< query.prepare("INSERT INTO  user_information (username, userpassword) VALUES (:username, :userpassword)");
    query.bindValue(":username", name);
    query.bindValue(":userpassword", password);
    qDebug()<<"wwwwwww\n"<<name<<password<<'\n';
    query.exec();


}
//修改用户密码
void sql::sql_revise( const QString &userpassword, const QString &username)
{
    qDebug()<<"修改"<<'\n';
    QSqlQuery query(db);
    qDebug()<<username<<"userpassword"<<userpassword<<'\n';
    query.prepare("update user_information set userpassword=:userpassword WHERE username=:username");
    query.bindValue(":username", username);
    query.bindValue(":userpassword", userpassword);
    query.exec();
    sql_find(db);
}



//修改信息
void sql::sql_infrom_revise(QString &from,QString &id ,QString &name,int &age,QString &phone_number ,int &score)
{

    QSqlQuery query(db);
    query.prepare("update "+from+" set name=:name, age=:age, phone_number=:phone_number, score=:score WHERE id=:id");
    query.bindValue(":id", id);
    query.bindValue(":name", name);
    query.bindValue(":age", age);
    query.bindValue(":phone_number", phone_number);
    query.bindValue(":score", score);
    query.exec();
    qDebug()<<"改后打印"<<'\n';
    sql_find(db);
}
//全部打印
void sql::infrom(QString &name)
{
    qDebug()<<"打印全部"<<'\n';
    QSqlQuery query(db);
    QString sql_s = "SELECT id, name, age, phone_number, score FROM "+name ; // 组装sql语句
    query.exec(sql_s);                                   // [2] 执行sql语句
    int i=0;
    while (query.next()) {                             // [3] 遍历查询结果
        i++;
        qDebug() << QString("%1, %2 ,%3 ,%4 ,%5")
                       .arg(query.value("id").toString())
                        .arg(query.value("name").toString())
                        .arg(query.value("age").toString())
                        .arg(query.value("phone_number").toString())
                        .arg(query.value("score").toString());
    }
    qDebug()<<"infrom  i="<<i<<'\n';
}
//删除信息
void sql::sql_infrom_del(QString &name,QString &id)
{
    QSqlQuery query(db);
    query.exec("delete from "+name+" where id = "+id);
    qDebug()<<"删除函数" <<'\n';
    query.exec();
    //数量
    qDebug()<<"数量"<<'\n';
}

//获取数据库用户数量
int sql::sql_size(const QString&from_name)
{
    QSqlQuery sql_query = QSqlQuery(db);
    QString select_max_sql = QString("select Count(*) from "+from_name);
    int num=0;
    sql_query.prepare(select_max_sql);
    if (!sql_query.exec())
    {
        qDebug() << "erre"<<sql_query.lastError();
    }
    else
    {
        while (sql_query.next())
        {

            num=sql_query.value(0).toInt();
        }

    }
    qDebug()<<num<<'\n';
    return num;

}
//查询
void sql::sql_infrom_name(QStandardItemModel &model,QString &uname,int num)
{
    xs(model,uname,num);
}
//学号查询信息
int  sql::infrom_student(QStandardItemModel &model,const QString &fromname,const QString &from,const QString &student_from)
{
    QSqlQuery query(db);    // [1] 传入数据库连接
    QString sql;
    sql = "SELECT * FROM "+fromname+" WHERE "+ from +"='" + student_from + "'";
    query.exec(sql);
    int i=0;
    int num=0;
    while(query.next()){
        i++;
    }
    if(i<=0){
        return 0;
    }
    else{
         num=i;
        qDebug()<<"i="<<i;
        query.first();
        model.setRowCount(i);
        query.previous();
        i=0;
    }
    while(query.next()){
        model.setData(model.index(i,0),QString("%1").arg(query.value("id").toString()));
        model.setData(model.index(i,1),QString("%1").arg(query.value("name").toString()));
        model.setData(model.index(i,2), QString("%1").arg(query.value("age").toString()));
        model.setData(model.index(i,3),QString("%1").arg(query.value("phone_number").toString()));
        model.setData(model.index(i,4), QString("%1").arg(query.value("score").toString()));
        ++i;
    }
    return num;
}
int sql::sql_ifrom_id(QSqlDatabase db,const QString &name,const QString &id)
{
    //int i=0;
    QSqlQuery query(db);    // [1] 传入数据库连接
    QString sql ;
    sql = "SELECT * FROM "+name+" WHERE id='"+id+"'";
        //多条遍历用循环
        //单条直接query.next();
    qDebug()<<"exec"<< query.exec(sql);
    //查看搜索结果
    query.next();
    QString ID=query.value("id").toString();
    qDebug()<<ID<<'\n';
    if(id!=ID ){

        return 1;
    }
    else{
        qDebug()<<"学号存在"<<'\n';
        return 0;
    }
}
//插入显示
//(id int primary key ,name varchar(20) , age int , phone_number varchar(20) ,score varchar(20))")
void sql::sql_infrom_add(QString &uname,QString &num,QString &name,int age ,QString &phone_number,int score)
{

    qDebug()<<"添加数据"<<'\n';
    QSqlQuery query(db);
    QString sql="INSERT INTO  "+uname+" (id, name, age, phone_number, score) VALUES (:id, :name, :age, :phone_number, :score)";
    if(query.prepare(sql))
    {
        qDebug()<<"插入"<<"成功";
    }
    else{

        qDebug()<<"失败"<<query.prepare(sql);
    }
    query.bindValue(":id", num);
    query.bindValue(":name", name);
    query.bindValue(":age", age);
    query.bindValue(":phone_number", phone_number);
    query.bindValue(":score", score);
    query.exec();

}


void sql::xs(QStandardItemModel &model,QString &uname,int num)
{

    QString sql_s = "SELECT id, name, age, phone_number, score FROM "+uname ; // 组装sql语句
    QSqlQuery query(db);                               // [1] 传入数据库连接
    query.exec(sql_s);                                   // [2] 执行sql语句
    int row=0;
    for(row=0;row<num;++row){
    query.next();                                      // [3] 遍历查询结果
        model.setRowCount(num);
                    model.setData(model.index(row,0),QString("%1").arg(query.value("id").toString()));
                    model.setData(model.index(row,1),QString("%1").arg(query.value("name").toString()));
                    model.setData(model.index(row,2), QString("%1").arg(query.value("age").toString()));
                    model.setData(model.index(row,3),QString("%1").arg(query.value("phone_number").toString()));
                    model.setData(model.index(row,4), QString("%1").arg(query.value("score").toString()));
    }
    }
