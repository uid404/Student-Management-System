#include "certified.h"
#include "ui_certified.h"
#include <QMessageBox>
#include <QRegularExpressionValidator>
#include<QChar>
certified::certified(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::certified)
{

    ui->setupUi(this);
    setWindowTitle("注册");

    ui->lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));
    ui->lineEdit_2->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]{20}")));
    ui->lineEdit->setStyleSheet("font-size:10px");
    ui->lineEdit->setPlaceholderText("请设置2位以上用户名");
    ui->lineEdit_2->setStyleSheet("font-size:10px");
    ui->lineEdit_2->setPlaceholderText("请设置8位以上密码");
}

certified::~certified()
{
    delete ui;
}


void certified::on_pushButton_clicked()
{
    this->close();
}

void certified::on_pushButton_2_clicked()
{
    QString name_text=ui->lineEdit->text();//用户名
    QString password_text=ui->lineEdit_2->text();//密码
    //QString username_1;
    if(name_text.size()!=0&&password_text.size()!=0){
    if(name_text[0]>='0'&&name_text[0]<= '9'){
         QMessageBox::information(this,tr("提示"),tr("用户名第一位不能为数字"),QMessageBox::Ok );

    }
    else{
    if(name_text.size()>=2){
        if(password_text.size()>=8){
           //username_1 ="username";
            //1. 账户相等 密码相等
            //2.账户相等 密码不相等
            //3.账户不相等
            if(a.sql_find_certified(a.db,name_text,password_text)==1){
                QMessageBox::information(this,tr("提示"),tr("已有该用户"),QMessageBox::Ok );
            }
            else{
            qDebug()<<"1"<<'\n';
            a.sql_add(a.db,ui->lineEdit->text(),ui->lineEdit_2->text());
            QMessageBox::information(this,tr("提示"),tr("注册成功"),QMessageBox::Ok );
            this->close();
            }
        }
        else{
            QMessageBox::information(this,tr("注意"),tr("密码长度小于8位,请重新输入"),QMessageBox::Ok );
        }
    }
    else{
        QMessageBox::information(this,tr("注意"),tr("用户名小于2位,请重新输入"),QMessageBox::Ok );
    }
    }
    }
    else{
    QMessageBox::information(this,tr("注意"),tr("用户名密码,不可为空"),QMessageBox::Ok );

    }
    //a.sql_find(a.db);
}

