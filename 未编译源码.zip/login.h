#ifndef LOGIN_H
#define LOGIN_H

//#include <QMainWindow>
#include<QStandardItemModel>
#include"sql.h"
namespace Ui {
class login;
}

class login : public QMainWindow
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();
signals:
    //信号关闭窗口
    void subClose();
public:
    void hfrom_name();
    void p_name(QString name);
    void print();
public slots:
    //自定义槽
    void pr_name(QString uname);

private slots:
    //槽
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_8_clicked();

public:
    QStandardItemModel *model;
private:
    //发送
    void closeEvent(QCloseEvent *){//重写关闭按钮事件
        emit subClose();//发出关闭信号，父窗体接收信号后显示窗体
    }
    //接收
    QString from_name_ok;
    sql a;
    Ui::login *ui;
};

#endif // LOGIN_H
