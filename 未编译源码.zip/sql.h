#ifndef SQL_H
#define SQL_H
#include <QMainWindow>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QSqlError>
#include<QStandardItemModel>
class sql
{
public:
    sql();
public:
    int sql_size(const QString&from_name);

    void sql_find(QSqlDatabase db);
    //添加用户
    void sql_add(QSqlDatabase db,const QString &name,const QString &password);
    //查找用户
    int sql_find_login(QSqlDatabase db, const QString &name,const QString &password);
    //查找用户的信息
    int sql_find_certified(QSqlDatabase db,const QString &name,const QString &password);
   //修改密码
    void sql_revise(const QString &name,const QString &password);// 更操作，修改数据
    //获取用户内的所有信息
    void sql_infrom_name(QStandardItemModel &model,QString &uname,int num=1);
    //添加用户内的信息
    void sql_infrom_add(QString &uname,QString &num,QString &name,int age ,QString &phone_number,int score);
    //
    int sql_ifrom_id(QSqlDatabase db,  const QString &name,const QString &id);
    //显示
    void sql_infrom_revise(QString &from,QString &id ,QString &name,int &age,QString &phone_number ,int &score);
    void infrom(QString&name);
    //
    void sql_infrom_del(QString &name,QString &id);
    //学号查询
    int infrom_student(QStandardItemModel &model,const QString &fromname,const QString &from,const QString &student_from);
    void xs(QStandardItemModel &model,QString &uname,int num=1);
    QSqlDatabase db;
};

#endif // SQL_H
