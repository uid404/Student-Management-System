#include "login.h"
#include "ui_login.h"
#include<QIcon>
//#include<QStandardItemModel>
#include <QRegularExpressionValidator>
#include<QTextBrowser>
#include<QMessageBox>
//#include"mainwindow.h"
login::login(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    ui->widget_2->close();
    ui->tableView->setStyleSheet("background-color: rgba(255, 255, 255, 30);");
    ui->textBrowser->setStyleSheet("background-color: rgba(255, 255, 255, 30);color: rgb(245, 252, 197);font: 400 9pt 'Microsoft YaHei UI';");

    //ui->setWindowTitle("管理页面");
    this->setWindowIcon(QIcon("ic/tubiao.ico"));
    //限制输入学号
    ui->lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[0-9]{11}")));
    //限制输入学号
     ui->lineEdit_2->setValidator(new QRegularExpressionValidator(QRegularExpression("[\u4e00-\u9fa5]+$")));
    //限制输入学号
    ui->lineEdit_3->setValidator(new QRegularExpressionValidator(QRegularExpression("[0-9]{3}")));
     //限制输入学号
    ui->lineEdit_4->setValidator(new QRegularExpressionValidator(QRegularExpression("[0-9]{11}")));
    //限制输入学号
     ui->lineEdit_5->setValidator(new QRegularExpressionValidator(QRegularExpression("[0-9]{3}")));

      ui->lineEdit_7->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]{20}")));
      ui->lineEdit_8->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]{20}")));
       ui->lineEdit_9->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]{20}")));
//获取管理的表
   // qDebug()<<"密码用户名正确";
    model=new QStandardItemModel(this);
       //绑定
    ui->tableView->setModel(model);
    ui->tableView->setStyleSheet("background-color: rgba(255, 255, 255, 30);color: rgb(0, 0, 0);font: 700 9pt 'Microsoft YaHei UI';");
   // ui->tableView->horizontalHeader()->hide();
    ui->tableView->setColumnWidth(0,10);
    ui->tableView->setColumnWidth(1,50);
    ui->tableView->setColumnWidth(2,10);
    ui->tableView->setColumnWidth(3,150);
    ui->tableView->setColumnWidth(4,10);



    model->setHorizontalHeaderItem(0, new QStandardItem("学号"));
    model->setHorizontalHeaderItem(1, new QStandardItem("姓名"));
    model->setHorizontalHeaderItem(2, new QStandardItem("年龄"));
    model->setHorizontalHeaderItem(3, new QStandardItem("手机号"));
    model->setHorizontalHeaderItem(4, new QStandardItem("成绩"));
    ui->tableView->verticalHeader()->hide();

//id int primary key ,name varchar(20) , age int , phone_number varchar(20) ,score varchar(20)
}

login::~login()
{
    qDebug()<<"析构";
    delete ui;
}



void login::print()
{
    qDebug()<<this->from_name_ok<<'\n';
}

void login::pr_name(QString uname)
{
    from_name_ok=uname;
    qDebug()<<"构造"<<from_name_ok<<'\n';
    a.sql_infrom_name(*model,from_name_ok,a.sql_size(from_name_ok));
    setWindowTitle("管理页面- "+from_name_ok);
}

void login::on_pushButton_clicked()
{
    this->close();

}

//查询全部信息
void login::on_pushButton_2_clicked()
{

    ui->textBrowser->append("共有"+QString::number(a.sql_size(from_name_ok))+"条信息");
    a.sql_infrom_name(*model,from_name_ok,a.sql_size(from_name_ok));
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

}

//插入信息
void login::on_pushButton_3_clicked()
{

    QString str_num=ui->lineEdit->text();
    QString str_name=ui->lineEdit_2->text();
    QString str_age=ui->lineEdit_3->text();
    int age=str_age.toInt();
    QString str_phon=ui->lineEdit_4->text();
    QString str_score=ui->lineEdit_5->text();
    int score=str_score.toInt();
    //(QSqlDatabase db,  const QString &name,const int &id);
    if(str_num.size()!=0){
        if(str_name.size()!=0){
            if(str_age.size()!=0){

                int num=a.sql_ifrom_id(a.db,from_name_ok,str_num);
                if(num==1){
                    //插入
                    a.sql_infrom_add(from_name_ok,str_num,str_name,age,str_phon,score);
                    //查询已有数据
                    a.sql_infrom_name(*model,from_name_ok,a.sql_size(from_name_ok));
                }
                else
                {
                    if(num==0){
                         ui->textBrowser->append("已经有此学号");
                    }
                    else{
                         ui->textBrowser->append("还未存入数据");
                    }
                }
            }
            else{
                 ui->textBrowser->append("姓名不可为空");
            }
        }
        else{
        ui->textBrowser->append("姓名不可为空");
        }
    }
    else{
        ui->textBrowser->append("学号不可为空");
    }
}
//计算
void login::on_pushButton_6_clicked()
{
    ui->textBrowser->append("共有"+QString::number( a.sql_size(from_name_ok))+"条信息");
    a.infrom(from_name_ok);
}
//修改
void login::on_pushButton_4_clicked()
{
    QString name=from_name_ok;
    QString str_num=ui->lineEdit->text();
    QString str_age=ui->lineEdit_3->text();
    int age=str_age.toInt();
    QString str_score=ui->lineEdit_5->text();
    int score=str_score.toInt();
    QString str_name=ui->lineEdit_2->text();
    QString str_phon=ui->lineEdit_4->text();
    if(str_num.size()!=0&&str_age.size()!=0&&str_score.size()!=0&&str_name.size()!=0&&str_phon.size()!=0){
    ui->textBrowser->append("已修改学号"+str_num+"的信息");
    a.sql_infrom_revise(name,str_num,str_name,age,str_phon,score);

    a.sql_infrom_name(*model,from_name_ok,a.sql_size(from_name_ok));
    }
    else{
    ui->textBrowser->append("请输入全部信息进行修改");
    }
}
//删除
void login::on_pushButton_5_clicked()
{
    QString id=ui->lineEdit->text();
    if(id.size()!=0){
    ui->textBrowser->append("已删除学号"+id+"的信息");
    //删除
    a.sql_infrom_del(from_name_ok,id);
    int i=a.sql_size(id);
    qDebug()<<i;
    a.sql_infrom_name(*model,from_name_ok,a.sql_size(from_name_ok));
    if(a.sql_size(from_name_ok)==0){
        model->removeRows(0,model->rowCount());
    }
    }
    else{
    ui->textBrowser->append("请输入学号进行删除信息");

    }
}

//搜索
void login::on_pushButton_7_clicked()
{
    qDebug()<<ui->comboBox_2->currentText();
    QString search=ui->comboBox_2->currentText();
    //输入的信息搜索
    QString input_infrom=ui->lineEdit_6->text();
    QString ui_name;
    QString num=0;
    int numbers;
    qDebug()<<input_infrom<<'\n';
    ////(id int primary key ,name varchar(20) , age int , phone_number varchar(20) ,score varchar(20))")
    if(search=="学号"){
        if(input_infrom.size()!=0){
            ui_name="id";
            numbers=a.infrom_student(*model,from_name_ok,ui_name,input_infrom);
            num=QString::number(numbers);
            if(numbers!=0){
               ui->textBrowser->append("共有"+num+"条信息");
            }
            else{
               ui->textBrowser->append("没有记录");
            }
        }
        else{
            ui->textBrowser->append("学号不可为空");
            //qDebug()<<"学号不可为空";
        }
    }

    if(search=="姓名"){
        if(input_infrom.size()!=0){
            ui_name="name";
            numbers=a.infrom_student(*model,from_name_ok,ui_name,input_infrom);
            num=QString::number(numbers);
            if(numbers!=0){
               ui->textBrowser->append("共有"+num+"条信息");
            }
            else{
               ui->textBrowser->append("没有记录");
            }
        }
        else{
            ui->textBrowser->append("姓名不可为空");
        }
    }

    if(search=="年龄"){
        if(input_infrom.size()!=0){
            ui_name="age";
            numbers=a.infrom_student(*model,from_name_ok,ui_name,input_infrom);
            num=QString::number(numbers);
            if(numbers!=0){
               ui->textBrowser->append("共有"+num+"条信息");
            }
            else{
               ui->textBrowser->append("没有记录");
            }
        }
        else{
            ui->textBrowser->append("年龄不可为空");
        }
    }
    if(search=="手机号"){
        if(input_infrom.size()!=0){
        ui_name="phone_number";
            numbers=a.infrom_student(*model,from_name_ok,ui_name,input_infrom);
            num=QString::number(numbers);
            if(numbers!=0){
               ui->textBrowser->append("共有"+num+"条信息");
            }
            else{
               ui->textBrowser->append("没有记录");
            }
          }
          else{
         ui->textBrowser->append("手机号不可为空");
          }
    }
    if(search=="成绩"){
          if(input_infrom.size()!=0){
        ui_name="score";
        numbers=a.infrom_student(*model,from_name_ok,ui_name,input_infrom);
        num=QString::number(numbers);
        if(numbers!=0){
               ui->textBrowser->append("共有"+num+"条信息");
            }
        else{
               ui->textBrowser->append("没有记录");
            }
          }
          else{
         ui->textBrowser->append("成绩不可为空");
          }
    }


}


void login::on_pushButton_9_clicked()
{

    ui->widget_2->show();

}

//修改密码槽
void login::on_pushButton_10_clicked()
{
    //ui->textBrowser_2->setFocusPolicy ( Qt ::NoFocus);
    ui->widget_2->close();
}

//确定
void login::on_pushButton_8_clicked()
{

   // QString usname="username";
    QString get_password=ui->lineEdit_7->text();
    //from_name_ok;
    int i=a.sql_find_certified(a.db,from_name_ok,get_password);
    if(get_password.size()!=0){
          if(i==1){
         QString password_1=ui->lineEdit_8->text();
         QString password_2=ui->lineEdit_9->text();
         if(password_1.size()!=0){
               if(password_1.size()>=8){
               if(password_2.size()!=0){
                 if(password_2.size()>=8){
                    if(password_1==password_2){

                         a.sql_revise(password_2,from_name_ok);
                         QMessageBox::information(this,tr("注意"),tr("密码已修改"),QMessageBox::Ok );
                         ui->widget_2->close();
                          QMessageBox::information(this,tr("注意"),tr("登录信息失效\n请重新登录系统"),QMessageBox::Ok );
                         this->close();
                    }else
                    {

                        QMessageBox::information(this,tr("警告"),tr("新密码输入不一致"),QMessageBox::Ok );
                    }
                          }
                          else{
                   QMessageBox::information(this,tr("注意"),tr("新密码至少8位"),QMessageBox::Ok );

                          }

               }

               else{
                      QMessageBox::information(this,tr("注意"),tr("新密码为空"),QMessageBox::Ok );

               }

               }
               else{

                QMessageBox::information(this,tr("注意"),tr("新密码至少8位"),QMessageBox::Ok );

               }

         }
         else{

                QMessageBox::information(this,tr("注意"),tr("新密码为空"),QMessageBox::Ok );
         }


          }
          else{
         QMessageBox::information(this,tr("警告"),tr("旧密码错误"),QMessageBox::Ok );
          }

    }
        else{

     QMessageBox::information(this,tr("警告"),tr("旧密码为空"),QMessageBox::Ok );
    }
}
