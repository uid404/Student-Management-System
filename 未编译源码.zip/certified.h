#ifndef CERTIFIED_H
#define CERTIFIED_H

#include <QMainWindow>
#include"sql.h"
//#include<mainwindow.h>
namespace Ui {
class certified;
}

class certified : public QMainWindow
{
    Q_OBJECT

public:
    explicit certified(QWidget *parent = nullptr);
    ~certified();
signals:
     void subClose();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:

    void closeEvent(QCloseEvent *){//重写关闭按钮事件
        emit subClose();//发出关闭信号，父窗体接收信号后显示窗体
    }
    sql a;
    Ui::certified *ui;
};

#endif // CERTIFIED_H
