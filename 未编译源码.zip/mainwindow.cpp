#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QSqlError>
#include<QLineEdit>
#include<QPushButton>
#include <QRegularExpressionValidator>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("登录");
    ui->lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]+$")));

    ui->lineEdit_2->setValidator(new QRegularExpressionValidator(QRegularExpression("[a-zA-Z0-9]{20}")));

    ui->lineEdit->setPlaceholderText("用户名");
    ui->lineEdit_2->setPlaceholderText("密码");
   // ui->lineEdit->setFocusPolicy(Qt::ClickFocus);
   // ui->lineEdit_2->setFocusPolicy(Qt::ClickFocus);
    ui->widget->setFocusPolicy(Qt::ClickFocus);
    ui->label_3->close();

}


MainWindow::~MainWindow()
{
    delete ui;
}


//登录
void MainWindow::on_pushButton_clicked()
{


    int num=0;
    //1. 账户相等 密码相等
    //2.账户相等 密码不相等
    //3.账户不相等
    QString name1=ui->lineEdit->text();
    qDebug()<<name1<<'\n';
    QString password1=ui->lineEdit_2->text();

    if(name1.size()!=0&&password1.size()!=0){
        ui->label_3->close();
    num=a.sql_find_certified(a.db,ui->lineEdit->text(),ui->lineEdit_2->text());//a.sql_find_login(a.db,ui->lineEdit->text(),ui->lineEdit_2->text());
        QSqlQuery query(a.db);
    //1. 用户名错误
    //2.密码错误
    //3.正确登录

    if(num==4){
         ui->label_3->show();
         ui->label_3->setText("数据库链接失败");

    }
    if(num==3){
          ui->label_3->show();
        ui->label_3->setText("用户名错误请重新输入");

    }
    if(num==2){
        ui->label_3->show();
        ui->label_3->setText("密码错误请重新输入");
    }
    if(num==1){
        ui->label_3->close();

        qDebug()<<query.exec("create table "+name1+" (id varchar(10) primary key ,name varchar(20),age varchar(20), phone_number varchar(20),score varchar(20))");
        login *admin=new login;
        this->close();
        connect(admin,&login::subClose,this,&QWidget::show);//关联子窗体关闭信号与父窗体显示事件
        connect(this,&MainWindow::send_name,admin,&login::pr_name);
        admin->setAttribute(Qt::WA_DeleteOnClose);//设置子窗体属性：关闭即销毁
        emit send_name(ui->lineEdit->text());
        //ui->lineEdit->clear();
        admin->show();//显示子窗体
        ui->lineEdit_2->clear();
        this->close();
        //qDebug()<<"from_name2="<<from_nama<<'\n';
    }
    }
    else{
       ui->label_3->show();
    if(name1.size()==0){

          ui->label_3->setText("请输入用户名");

    }
    else{
              ui->label_3->setText("请输入密码");

          }

    }


}

//注册
void MainWindow::on_pushButton_2_clicked()
{

    //创建一个表
    QSqlQuery query(a.db);
    qDebug()<<query.exec("create table user_information (username varchar(20) primary key ,userpassword varchar(20))");
    certified*admin=new certified;
    admin->show();
    this->close();
    connect(admin,&certified::subClose,this,&QWidget::show);//关联子窗体关闭信号与父窗体显示事件
    admin->setAttribute(Qt::WA_DeleteOnClose);//设置子窗体属性：关闭即销毁
    admin->show();//显示子窗体

}

